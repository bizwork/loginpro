package com.example.newapp;

import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class loginActivity extends AppCompatActivity {
    // UI references.
    private EditText email_id,pass;
    private Button button_send;
    private TextView sign_in;


    // [START declare_auth]
    private FirebaseAuth mAuth;
    // [END declare_auth]

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);



        // Set up the login form.
        mAuth = FirebaseAuth.getInstance();
        email_id = findViewById(R.id.email);
        pass = findViewById(R.id.password);
        button_send =findViewById(R.id.button);
        sign_in = findViewById(R.id.signText);

// [START initialize_auth]
        mAuth = FirebaseAuth.getInstance();
        // [END initialize_auth]

    }

    // [START on_start_check_user]
    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        updateUI(currentUser);
    }
    // [END on_start_check_user]



    private void signIn(String email, String password) {
        if (!validateForm()) {
            return;
        }



        // [START sign_in_with_email]
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            FirebaseUser user = mAuth.getCurrentUser();
                            updateUI(user);
                        } else {
                            // If sign in fails, display a message to the user.
                            Toast.makeText(loginActivity.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                            updateUI(null);
                        }



                        // [END_EXCLUDE]
                    }
                });
        // [END sign_in_with_email]
    }
    private boolean validateForm() {
        boolean valid = true;

        String email = email_id.getText().toString().trim();
        if (TextUtils.isEmpty(email)) {email_id.setError("Email can't be empty.");
            valid = false;
        } else {
            email_id.setError(null);
        }

        String password = pass.getText().toString();
        if (TextUtils.isEmpty(password)) {
            pass.setError("Password can't be empty.");

            valid = false;
        } else {
            pass.setError(null);
        }

        return valid;
    }

    private void updateUI(FirebaseUser user) {
        if (user != null) {
            if (!user.isEmailVerified()){
                startActivity(new Intent(loginActivity.this,HomeActivity.class));
                finish();


            }else
                startActivity(new Intent(loginActivity.this,HomeActivity.class));
            finish();

        }
    }




    @Override
    public void onStop() {
        super.onStop();

    }



    public void Signinmeton(View view) {
        signIn(email_id.getText().toString().trim(), pass.getText().toString());
        //startActivity(new Intent(LoginActivity.this,MainActivity.class));
    }

    public void GoToSignup(View view) {
        startActivity(new Intent(loginActivity.this,MainActivity.class));
    }

    public void GoToForgotPassword(View view) {
        //startActivity(new Intent(LoginActivity.this,PasswordReset.class));
    }

}

